package chap05;

public class AdvancedForExample {

	public static void main(String[] args) {
		int[] scorse = {95, 71 , 84 , 93 ,87};
		
		int sum = 0;
		for (int score : scorse) {
			sum = sum + score;
		}
		System.out.println("정수 총합 =" + sum );
		
		double avg = (double) sum / scorse.length;
		System.out.println("점수 평균 =" + avg);
	}

}
