package chap01;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
