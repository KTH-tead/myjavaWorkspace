package chap02;

public class GarbageValueExample {
	
}
