package sec0;


public class GarbageValueExample {
	
}
