package sec0;


public class BooleanExapmle {
	public static void main(String[] args) {
		boolean stop = true;
		if(stop) {
			System.out.println("중지합니다");
		}
		else {
			System.out.println("시작합니다");
		}
	}
}
