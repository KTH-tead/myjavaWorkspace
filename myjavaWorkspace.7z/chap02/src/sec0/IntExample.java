package sec0;


public class IntExample {
	public static void main(String[] args) {
		int var1 = 10; //10진수로 저장
		int var2 = 012; // 8 진수로 저장
		int var3 = 0xA; // 16 진수로 저장
		
		System.out.println(var1);
		System.out.println(var2);
		System.out.println(var3);
		
	}
}
